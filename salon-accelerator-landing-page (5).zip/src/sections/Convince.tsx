import { useMemo, useState } from "react";
import { CTAButton, Eyebrow, Reveal, Section } from "../components/ui";
import { BRAND } from "../brand";

export function RoiCalculator() {
  const [stylists, setStylists] = useState(6);
  const [clients, setClients] = useState(8);
  const [days, setDays] = useState(5);
  const [avgRetail, setAvgRetail] = useState(42);
  const [lift, setLift] = useState(15);

  const { weekly, monthly, yearly } = useMemo(() => {
    const clientsPerWeek = stylists * clients * days;
    const newSales = clientsPerWeek * (lift / 100) * avgRetail;
    return {
      weekly: newSales,
      monthly: newSales * 4.33,
      yearly: newSales * 52,
    };
  }, [stylists, clients, days, avgRetail, lift]);

  const money = (n: number) =>
    "$" + Math.round(n).toLocaleString("en-AU");

  const sliders: [string, number, (v: number) => void, number, number, string][] =
    [
      ["Stylists on the floor", stylists, setStylists, 1, 20, ""],
      ["Clients per stylist, per day", clients, setClients, 1, 15, ""],
      ["Trading days per week", days, setDays, 3, 7, ""],
      ["Average retail / treatment sale", avgRetail, setAvgRetail, 15, 150, "$"],
      ["Realistic conversion lift", lift, setLift, 5, 40, "%"],
    ];

  return (
    <Section id="roi" className="bg-ink pt-28 text-cream md:pt-32">
      <div className="grid gap-12 lg:grid-cols-[1fr_1fr]">
        <Reveal>
          <div>
            <Eyebrow>Do the maths</Eyebrow>
            <h2 className="mt-5 font-display-light text-4xl leading-tight sm:text-5xl">
              What is “we don't really sell retail” costing you?
            </h2>
            <p className="mt-5 text-cream/65">
              Move the sliders to your salon's reality. Even a modest lift in
              recommendation conversion compounds fast across a full team.
            </p>

            <div className="mt-9 space-y-6">
              {sliders.map(([label, val, set, min, max, unit]) => (
                <div key={label}>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-cream/70">{label}</span>
                    <span className="font-display text-lg text-blush">
                      {unit === "$" ? "$" : ""}
                      {val}
                      {unit === "%" ? "%" : ""}
                    </span>
                  </div>
                  <input
                    type="range"
                    min={min}
                    max={max}
                    value={val}
                    onChange={(e) => set(Number(e.target.value))}
                    className="mt-2 h-1.5 w-full cursor-pointer appearance-none rounded-full bg-cream/20 accent-blush"
                  />
                </div>
              ))}
            </div>
          </div>
        </Reveal>

        <Reveal delay={120}>
          <div className="rounded-[2rem] border border-cream/15 bg-cream/5 p-8 md:p-10">
            <div className="text-[11px] font-semibold uppercase tracking-[0.25em] text-cream/50">
              Potential added revenue
            </div>
            <div className="mt-6 font-display text-6xl font-semibold text-blush sm:text-7xl">
              {money(yearly)}
            </div>
            <div className="mt-1 text-sm text-cream/60">per year</div>

            <div className="mt-8 grid grid-cols-2 gap-4">
              <div className="rounded-xl bg-cream/10 p-5">
                <div className="font-display text-2xl">{money(weekly)}</div>
                <div className="text-xs text-cream/55">per week</div>
              </div>
              <div className="rounded-xl bg-cream/10 p-5">
                <div className="font-display text-2xl">{money(monthly)}</div>
                <div className="text-xs text-cream/55">per month</div>
              </div>
            </div>

            <p className="mt-7 text-xs leading-relaxed text-cream/45">
              Illustrative estimate based on the numbers you enter. Results vary
              by salon, team and implementation — which is exactly why the
              30-day accountability session is built in.
            </p>

            <CTAButton variant="light" className="mt-7 w-full">
              Claim This Revenue
            </CTAButton>
          </div>
        </Reveal>
      </div>
    </Section>
  );
}

const QUESTIONS = [
  "Are you struggling to address common complaints showing up in your online reviews?",
  "Do consultations feel inconsistent, leading to misunderstandings or redo's?",
  "Does your team freeze when a client raises an objection?",
  "Do you want to lift retail sales but aren't sure how to recommend naturally?",
  "Would stronger teamwork and collaboration change your salon's performance?",
  "Do your operations need simple systems and daily structure?",
  "Do you want client care and excellence to drive loyalty and referrals?",
  "Are you finding it hard to set and actually hit measurable growth goals?",
  "Does communication inside your salon need a serious upgrade?",
  "Are you ready to invest in your salon's profitability right now?",
];

export function FitQuiz() {
  const [answers, setAnswers] = useState<Record<number, boolean>>({});
  const yes = Object.values(answers).filter(Boolean).length;
  const answered = Object.keys(answers).length;

  const verdict =
    yes >= 5
      ? {
          h: "The Accelerator Course is built for you.",
          p: `You said yes to ${yes} of 10. Every one of those is addressed directly on training day — and reviewed again at your 30-day accountability session.`,
        }
      : yes >= 1
      ? {
          h: "There's revenue sitting on your shelves.",
          p: `You said yes to ${yes} of 10. If you answered yes to even one, this could be the game changer you've been looking for.`,
        }
      : {
          h: "Answer the questions above.",
          p: "Tap yes or no to see whether the Accelerator Course is the right fit for your salon.",
        };

  return (
    <Section id="fit">
      <Reveal>
        <div className="mx-auto max-w-2xl text-center">
          <Eyebrow>60-second fit check</Eyebrow>
          <h2 className="mt-5 font-display-light text-4xl leading-tight sm:text-5xl">
            Will the Accelerator Course actually benefit you?
          </h2>
          <p className="mt-5 text-ink/65">
            It's a fair question. Answer honestly — the result tells you
            everything.
          </p>
        </div>
      </Reveal>

      <div className="mt-12 grid gap-8 lg:grid-cols-[1.25fr_0.75fr]">
        <div className="space-y-3">
          {QUESTIONS.map((q, i) => (
            <Reveal key={i} delay={i * 30}>
              <div className="flex items-center gap-4 rounded-2xl border border-sand bg-white p-4 sm:p-5">
                <p className="flex-1 text-sm leading-snug text-ink/80">{q}</p>
                <div className="flex shrink-0 gap-2">
                  {[true, false].map((v) => (
                    <button
                      key={String(v)}
                      onClick={() =>
                        setAnswers((a) => ({ ...a, [i]: v }))
                      }
                      className={`rounded-full border px-4 py-1.5 text-xs font-semibold transition ${
                        answers[i] === v
                          ? v
                            ? "border-rose bg-rose text-ink"
                            : "border-ink bg-ink text-cream"
                          : "border-ink/20 text-ink/60 hover:border-ink/50"
                      }`}
                    >
                      {v ? "Yes" : "No"}
                    </button>
                  ))}
                </div>
              </div>
            </Reveal>
          ))}
        </div>

        <div className="lg:sticky lg:top-28 lg:h-fit">
          <Reveal delay={100}>
            <div className="rounded-[2rem] bg-ink p-8 text-cream">
              <div className="flex items-end justify-between">
                <div className="text-[11px] font-semibold uppercase tracking-[0.22em] text-cream/50">
                  Your result
                </div>
                <div className="font-display text-3xl text-blush">
                  {yes}/10
                </div>
              </div>
              <div className="mt-4 h-2 w-full overflow-hidden rounded-full bg-cream/15">
                <div
                  className="h-full rounded-full bg-blush transition-all duration-500"
                  style={{ width: `${(yes / 10) * 100}%` }}
                />
              </div>
              <h3 className="mt-6 font-display text-2xl leading-snug">
                {verdict.h}
              </h3>
              <p className="mt-3 text-sm leading-relaxed text-cream/65">
                {verdict.p}
              </p>
              <div className="mt-4 text-xs text-cream/40">
                {answered}/10 answered
              </div>
              <CTAButton variant="light" className="mt-6 w-full">
                Talk To Sonia
              </CTAButton>
            </div>
          </Reveal>
        </div>
      </div>
    </Section>
  );
}

export function About() {
  return (
    <Section className="bg-sand/40">
      <div className="grid items-center gap-12 lg:grid-cols-[0.85fr_1.15fr]">
        <Reveal>
          <div className="relative">
            <img
              src={BRAND.soniaEducator}
              alt="Sonia Tomas, The Salon Dr., in-salon hair educator"
              className="h-[28rem] w-full rounded-[2rem] border-4 border-white object-cover object-top shadow-[0_40px_80px_-45px_rgba(33,33,33,0.6)]"
              loading="lazy"
            />
            <div className="absolute -bottom-6 left-5 rounded-2xl bg-white px-5 py-4 shadow-xl">
              <div className="font-display text-lg font-medium">Sonia Tomas</div>
              <div className="text-[10px] uppercase tracking-[0.2em] text-rose-deep">
                Founder · The Salon Dr.
              </div>
            </div>
          </div>
        </Reveal>

        <Reveal delay={100}>
          <div>
            <Eyebrow>Why this course exists</Eyebrow>
            <h2 className="mt-5 font-display-light text-4xl leading-tight sm:text-5xl">
              35 years in the industry taught me exactly where the money leaks.
            </h2>
            <div className="mt-6 space-y-4 text-ink/70">
              <p>
                “I started my apprenticeship in 1988 — and I really never
                stopped cutting hair. From the salon floor to the frontline of
                education and sales, I know where the real leaks are. I know
                how to fix them.
              </p>
              <p>
                So many salons were losing money every day by not wanting
                retail in their salon. Owners were sick of telling staff to
                sell — or worse, sick of stock sitting on the shelves
                collecting dust, with money tied up in product that never
                moved.
              </p>
              <p>
                The reluctance to recommend isn't carelessness or laziness.
                It's a <strong>lack of confidence</strong>. Hairdressers know
                the value of the products — they just struggle to communicate
                it. That is exactly what I teach.”
              </p>
            </div>

            <div className="mt-8 grid gap-4 sm:grid-cols-3">
              {[
                ["35+", "Years in hairdressing"],
                ["$5M+", "Annual revenue as a BDM"],
                ["1988", "Started on the floor"],
              ].map(([big, small]) => (
                <div
                  key={big}
                  className="rounded-2xl border border-rose/30 bg-white p-5"
                >
                  <div className="font-display text-2xl font-semibold text-rose-deep">
                    {big}
                  </div>
                  <div className="text-xs leading-snug text-ink/60">{small}</div>
                </div>
              ))}
            </div>

            <div className="mt-6 flex flex-wrap gap-3">
              {[
                "In-salon delivery",
                "Owners + team",
                "Implementation first",
                "Australia wide",
              ].map((t) => (
                <span
                  key={t}
                  className="rounded-full border border-ink/15 bg-white px-4 py-2 text-xs font-semibold text-ink/70"
                >
                  {t}
                </span>
              ))}
            </div>
          </div>
        </Reveal>
      </div>
    </Section>
  );
}

const OUTCOMES = [
  "More confident consultations and client conversations",
  "Stronger retail and treatment recommendations",
  "Clear KPIs, targets and accountability",
  "A more consistent and profitable client journey",
  "Practical systems your team implements immediately",
];

export function Outcomes() {
  return (
    <Section>
      <Reveal>
        <div className="rounded-[2.5rem] border border-sand bg-white p-8 md:p-14">
          <div className="grid gap-10 lg:grid-cols-[0.9fr_1.1fr]">
            <div>
              <Eyebrow>The outcome</Eyebrow>
              <h2 className="mt-5 font-display-light text-4xl leading-tight sm:text-5xl">
                What your team walks away with.
              </h2>
              <p className="mt-5 text-ink/60">
                Plus workbooks, certificates and team gifts to reinforce the
                learning long after the day ends.
              </p>
              <CTAButton className="mt-8">Reserve Your Date</CTAButton>
            </div>
            <ul className="space-y-1">
              {OUTCOMES.map((o, i) => (
                <li
                  key={o}
                  className="flex items-center gap-5 border-b border-sand py-5 last:border-0"
                >
                  <span className="font-display text-2xl text-blush">
                    0{i + 1}
                  </span>
                  <span className="font-display text-lg font-medium leading-snug">{o}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </Reveal>
    </Section>
  );
}

const FAQS = [
  {
    q: "How long is the training and where does it happen?",
    a: "It's a 5-hour live session that can be delivered in your salon or live online over Zoom. In-salon means training happens in the exact environment your team works in — using your menu, your products and your numbers. Online keeps it just as interactive, with the option to split it into two shorter sessions.",
  },
  {
    q: "Is the online version as effective as in-salon?",
    a: "The framework, workbooks and 30-day accountability session are identical. In-salon wins on team energy and hands-on retail-shelf work, so it's our pick for teams of four or more. Online is ideal for regional salons, smaller teams or split-shift rosters — and it's always live with Sonia, never a pre-recorded course.",
  },
  {
    q: "Can we split the online training across multiple days?",
    a: "Yes. Online delivery can run as one 5-hour block or as two 2.5-hour sessions so you don't have to close the salon for a full day. We'll build it around your roster.",
  },
  {
    q: "Is this for owners or for staff?",
    a: "Both, together. The retail and consultation gap is created by owners and team members alike, so the course is designed to be attended as a whole salon.",
  },
  {
    q: "Will my team feel like they're being taught to 'sell'?",
    a: "No. The entire approach is service-led. Your team learns to educate, uncover needs and recommend solutions naturally — which happens to be the most profitable way to sell.",
  },
  {
    q: "What happens after the training day?",
    a: "You receive workbooks, certificates and team gifts, plus a 30-day accountability Zoom session with Sonia to review your personalised accountability card, reinforce new habits and keep momentum moving.",
  },
  {
    q: "We've done education before and nothing changed. Why is this different?",
    a: "Because accountability is built in. Commitments are made in writing on the day and reviewed 30 days later. That follow-up is The Salon Dr's main point of difference.",
  },
  {
    q: "What does it cost and how do we book?",
    a: "Investment depends on your team size, location and whether you choose in-salon or online delivery. Submit the enquiry form and Sonia will come back to you with availability and a tailored proposal for your salon.",
  },
];

export function FAQ() {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <Section id="faq">
      <div className="grid gap-10 lg:grid-cols-[0.8fr_1.2fr]">
        <Reveal>
          <div>
            <Eyebrow>Questions</Eyebrow>
            <h2 className="mt-5 font-display-light text-4xl leading-tight sm:text-5xl">
              Everything else you're wondering.
            </h2>
            <p className="mt-5 text-ink/60">
              Still unsure? Send an enquiry and ask directly — no pressure, no
              scripts.
            </p>
          </div>
        </Reveal>
        <div className="divide-y divide-sand border-y border-sand">
          {FAQS.map((f, i) => (
            <div key={f.q}>
              <button
                onClick={() => setOpen(open === i ? null : i)}
                className="flex w-full items-center justify-between gap-6 py-6 text-left"
              >
                <span className="font-display text-lg font-medium leading-snug">{f.q}</span>
                <span
                  className={`grid h-8 w-8 shrink-0 place-items-center rounded-full border border-ink/20 transition ${
                    open === i ? "rotate-45 bg-ink text-cream" : ""
                  }`}
                >
                  +
                </span>
              </button>
              <div
                className={`grid transition-all duration-300 ${
                  open === i
                    ? "grid-rows-[1fr] pb-6 opacity-100"
                    : "grid-rows-[0fr] opacity-0"
                }`}
              >
                <div className="overflow-hidden text-ink/65">{f.a}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </Section>
  );
}
