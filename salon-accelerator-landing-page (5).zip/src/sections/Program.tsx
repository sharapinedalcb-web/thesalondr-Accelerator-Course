import { useEffect, useState } from "react";
import { CTAButton, Eyebrow, Reveal, Section } from "../components/ui";
import { BRAND } from "../brand";

type IconName =
  | "clock"
  | "chat"
  | "bottle"
  | "diamond"
  | "journey"
  | "chart"
  | "huddle"
  | "flame";

const iconProps = {
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 1.4,
  strokeLinecap: "round" as const,
  strokeLinejoin: "round" as const,
};

function FeatureIcon({ name }: { name: IconName }) {
  return (
    <svg viewBox="0 0 32 32" className="h-6 w-6" aria-hidden {...iconProps}>
      {name === "clock" && (
        <>
          <circle cx="16" cy="17" r="9.5" />
          <path d="M16 11.5v5.8l3.6 2.2" />
          <path d="M12.5 5.2h7" />
          <path d="M16 5.2V7.5" />
        </>
      )}
      {name === "chat" && (
        <>
          <path d="M6 9.5A3.5 3.5 0 0 1 9.5 6h13A3.5 3.5 0 0 1 26 9.5v8a3.5 3.5 0 0 1-3.5 3.5H15l-5.6 4v-4H9.5A3.5 3.5 0 0 1 6 17.5z" />
          <path d="M12 12.2h9.5M12 16.2h6" />
        </>
      )}
      {name === "bottle" && (
        <>
          <path d="M13.2 12h5.6v12.6a2.4 2.4 0 0 1-2.4 2.4h-.8a2.4 2.4 0 0 1-2.4-2.4z" />
          <path d="M13.2 12V9.4h5.6V12" />
          <path d="M14.6 7.2h2.8v2.2h-2.8z" />
          <path d="M15.2 5h1.6v2.2h-1.6z" />
          <path d="M13.6 17.4h4.8" />
        </>
      )}
      {name === "diamond" && (
        <>
          <path d="M10.4 8.2h11.2l4 5.8L16 25.4 6.4 14z" />
          <path d="M6.4 14h19.2" />
          <path d="M13 8.2 11.8 14 16 25.4 20.2 14 19 8.2" />
        </>
      )}
      {name === "journey" && (
        <>
          <circle cx="8.2" cy="9" r="3" />
          <circle cx="23.8" cy="23" r="3" />
          <path d="M11.2 9h6.3a3.8 3.8 0 0 1 0 7.6h-4.4a3.8 3.8 0 0 0 0 7.6h7.8" />
          <path d="M8.2 12v6.4" />
        </>
      )}
      {name === "chart" && (
        <>
          <path d="M6 6v20h20" />
          <path d="M10.4 21.6v-5.2" />
          <path d="M16 21.6V11.2" />
          <path d="M21.6 21.6v-8.4" />
          <path d="M9.4 8.6h4.2" />
        </>
      )}
      {name === "huddle" && (
        <>
          <circle cx="16" cy="16" r="9.8" />
          <circle cx="16" cy="16" r="4.2" />
          <path d="M16 4.4v3.2M16 24.4v3.2M4.4 16h3.2M24.4 16h3.2" />
          <path d="M8.6 8.6l2.2 2.2M21.2 21.2l2.2 2.2M23.4 8.6l-2.2 2.2M10.8 21.2l-2.2 2.2" />
        </>
      )}
      {name === "flame" && (
        <>
          <path d="M16 4.8c4.2 4.6 7 7.9 7 12.4a7 7 0 0 1-14 0c0-2.5 1.2-4.3 3-6.2.5 2 1.3 3.2 2.4 3.9.2-4 .6-7.2 1.6-10.1z" />
          <path d="M16 17.4c1.5 1.4 2.2 2.3 2.2 3.7a2.4 2.4 0 0 1-4.8 0c0-1.3.7-2.3 2-3.7z" />
        </>
      )}
    </svg>
  );
}

const INCLUDED = [
  {
    icon: "clock",
    t: "5-Hour In-Salon Training Session",
    d: "Live, practical training focused on implementation — not theory.",
  },
  {
    icon: "chat",
    t: "Consultation Mastery",
    d: "Build confidence uncovering client needs and recommending solutions naturally.",
  },
  {
    icon: "bottle",
    t: "Retail Confidence Training",
    d: "Help your team educate and serve clients without feeling pushy or sales-focused.",
  },
  {
    icon: "diamond",
    t: "Treatment & High-Ticket Strategy",
    d: "Introduce premium treatments, upgrades and services with confidence.",
  },
  {
    icon: "journey",
    t: "Client Journey Mapping",
    d: "A consistent, profitable experience from consultation to rebooking and aftercare.",
  },
  {
    icon: "chart",
    t: "KPI & Target Clarity",
    d: "Practical benchmarks so every team member knows exactly what to aim for.",
  },
  {
    icon: "huddle",
    t: "Systems & Daily Structure",
    d: "Simple systems — including the Daily Huddle — for consistency and accountability.",
  },
  {
    icon: "flame",
    t: "Team Engagement & Mindset",
    d: "Dismantle limiting beliefs around selling, pricing and communicating value.",
  },
];

const FRAMEWORKS = [
  {
    t: "Principles of C.A.R.E.",
    d: "Care, Attention, Respect and Excellence in every client interaction — the engine behind loyalty and referrals.",
  },
  {
    t: "The 10x10 Rule",
    d: "Consistency and repetition compounded into extraordinary salon performance.",
  },
  {
    t: "Communication Rating",
    d: "Audit your salon's communication channels and close the gaps with clients and team.",
  },
  {
    t: "Goal Setting for Results",
    d: "Clear, actionable goals with tracking so progress becomes measurable, not hopeful.",
  },
  {
    t: "Teamwork & Team Building",
    d: "A culture of collaboration that lifts morale, productivity and salon-wide results.",
  },
  {
    t: "Consultation Cheat Sheet",
    d: "Scripts, prompts and tools so every consultation is delivered at the same high standard.",
  },
];

export function Included() {
  return (
    <Section id="included">
      <Reveal>
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div className="max-w-2xl">
            <Eyebrow>What's included</Eyebrow>
            <h2 className="mt-5 font-display-light text-4xl leading-tight sm:text-5xl">
              Everything your team needs to sell with integrity.
            </h2>
          </div>
          <p className="max-w-sm text-sm leading-relaxed text-ink/60">
            Delivered in one focused day inside your salon, with workbooks,
            certificates and team gifts to lock the learning in.
          </p>
        </div>
      </Reveal>

      <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {INCLUDED.map((c, i) => (
          <Reveal key={c.t} delay={i * 60}>
            <div className="flex h-full flex-col rounded-2xl border border-sand bg-white p-6 transition-all duration-300 hover:-translate-y-1.5 hover:shadow-[0_28px_60px_-34px_rgba(180,85,111,0.6)]">
              <div className="mb-5 grid h-12 w-12 place-items-center rounded-xl bg-sand text-ink">
                <FeatureIcon name={c.icon as IconName} />
              </div>
              <h3 className="font-display text-base font-medium leading-snug">
                {c.t}
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-ink/60">{c.d}</p>
            </div>
          </Reveal>
        ))}
      </div>

      <Reveal>
        <div className="mt-16 grid items-center gap-10 rounded-[2rem] border border-sand bg-sand/40 p-8 md:p-12 lg:grid-cols-[0.75fr_1.25fr]">
          <img
            src={BRAND.coursePoster}
            alt="The Accelerator Course by The Salon Dr."
            className="mx-auto w-full max-w-xs rounded-2xl shadow-[0_30px_60px_-35px_rgba(33,33,33,0.6)]"
            loading="lazy"
          />
          <div>
            <Eyebrow>The frameworks</Eyebrow>
            <h3 className="mt-4 font-display-light text-3xl sm:text-4xl">
              Tools your team will still be using in 12 months.
            </h3>
            <div className="mt-8 grid gap-x-10 gap-y-6 sm:grid-cols-2">
              {FRAMEWORKS.map((f, i) => (
                <div key={f.t} className="border-t border-rose/30 pt-4">
                  <div className="font-display text-xs font-semibold tracking-widest text-rose-deep">
                    0{i + 1}
                  </div>
                  <h4 className="mt-1 font-display text-lg font-medium">
                    {f.t}
                  </h4>
                  <p className="mt-1.5 text-sm leading-relaxed text-ink/60">
                    {f.d}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </Reveal>
    </Section>
  );
}

const AGENDA = [
  {
    time: "Hour 1",
    t: "Mindset & Money Beliefs",
    d: "Why your team resists selling — and how to replace that story with service-led confidence.",
  },
  {
    time: "Hour 2",
    t: "Consultation Mastery",
    d: "The question framework that uncovers real needs, plus objection handling that feels human.",
  },
  {
    time: "Hour 3",
    t: "Retail & Treatment Confidence",
    d: "Natural recommendation language, product storytelling and premium service upgrades.",
  },
  {
    time: "Hour 4",
    t: "Client Journey & C.A.R.E.",
    d: "Map the journey from booking to rebooking so nothing profitable gets skipped.",
  },
  {
    time: "Hour 5",
    t: "KPIs, Huddles & Commitments",
    d: "Set targets, install the Daily Huddle, and every team member signs an accountability card.",
  },
];

export function TrainingDay() {
  const [active, setActive] = useState(0);
  return (
    <Section id="day" className="bg-ink text-cream">
      <Reveal>
        <div className="max-w-2xl">
          <Eyebrow>The training day</Eyebrow>
          <h2 className="mt-5 font-display-light text-4xl leading-tight sm:text-5xl">
            Five hours that change how your salon{" "}
            <span className="font-semibold text-blush">
              talks, sells and serves.
            </span>
          </h2>
        </div>
      </Reveal>

      <div className="mt-12 grid gap-8 lg:grid-cols-[0.9fr_1.1fr]">
        <div className="space-y-2">
          {AGENDA.map((a, i) => (
            <button
              key={a.t}
              onMouseEnter={() => setActive(i)}
              onClick={() => setActive(i)}
              className={`flex w-full items-center gap-4 rounded-xl border px-5 py-4 text-left transition-all duration-300 ${
                active === i
                  ? "border-blush/70 bg-cream/10"
                  : "border-cream/10 hover:border-cream/30"
              }`}
            >
              <span
                className={`text-[10px] font-semibold uppercase tracking-[0.2em] ${
                  active === i ? "text-blush" : "text-cream/40"
                }`}
              >
                {a.time}
              </span>
              <span className="font-display text-base">{a.t}</span>
            </button>
          ))}
        </div>

        <div className="overflow-hidden rounded-[1.75rem] border border-cream/15 bg-cream/5">
          <img
            src={BRAND.workbooks}
            alt="Salon team with Accelerator Course workbooks"
            className="h-48 w-full object-cover"
            loading="lazy"
          />
          <div className="p-8 md:p-10">
            <div className="text-[11px] font-semibold uppercase tracking-[0.25em] text-blush">
              {AGENDA[active].time}
            </div>
            <h3 className="mt-3 font-display text-2xl">{AGENDA[active].t}</h3>
            <p className="mt-3 text-lg leading-relaxed text-cream/70">
              {AGENDA[active].d}
            </p>
            <div className="mt-7 grid gap-3 border-t border-cream/15 pt-6 text-sm text-cream/60 sm:grid-cols-2">
              <div>✓ Delivered in your salon, on your floor</div>
              <div>✓ Owners and team trained together</div>
              <div>✓ Workbooks, certificates & team gifts</div>
              <div>✓ Scripts ready to use next morning</div>
            </div>
          </div>
        </div>
      </div>
    </Section>
  );
}

export function Accountability() {
  return (
    <Section id="accountability">
      <div className="grid items-center gap-12 lg:grid-cols-2">
        <Reveal>
          <div className="relative">
            <div className="overflow-hidden rounded-[2rem] rounded-bl-[6rem] border-4 border-white shadow-[0_40px_80px_-45px_rgba(33,33,33,0.55)]">
              <img
                src={BRAND.accountability}
                alt="The Salon Dr. 30-day accountability session"
                className="h-[24rem] w-full object-cover sm:h-[30rem]"
                loading="lazy"
              />
            </div>
            <img
              src={BRAND.commitmentCard}
              alt="Personalised accountability commitment card"
              className="absolute -right-4 -bottom-8 w-36 rotate-3 rounded-xl border-4 border-white shadow-2xl sm:w-44"
              loading="lazy"
            />
            <div className="absolute -left-4 top-6 rounded-2xl bg-rose px-5 py-4 text-ink shadow-xl">
              <div className="font-display text-3xl font-semibold">30</div>
              <div className="text-[10px] font-semibold uppercase tracking-[0.18em]">
                Day accountability
              </div>
            </div>
          </div>
        </Reveal>

        <Reveal delay={120}>
          <div>
            <Eyebrow>The point of difference</Eyebrow>
            <h2 className="mt-5 font-display-light text-4xl leading-tight sm:text-5xl">
              Most training ends at 5pm. This one keeps going.
            </h2>
            <p className="mt-5 text-lg leading-relaxed text-ink/70">
              Thirty days after your training, you sit down with Sonia on Zoom
              and review your personalised accountability card — the goals your
              team set, the progress made, and the roadblocks in the way.
            </p>
            <ul className="mt-7 space-y-4">
              {[
                "Review every commitment made on training day",
                "Troubleshoot the habits that didn't stick",
                "Reset targets and celebrate the wins",
                "Lock in sustainable sales habits for good",
              ].map((x) => (
                <li key={x} className="flex gap-3 text-ink/75">
                  <span className="mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-full bg-rose text-xs text-white">
                    ✓
                  </span>
                  <span>{x}</span>
                </li>
              ))}
            </ul>
            <div className="mt-8 rounded-2xl border-l-4 border-rose bg-sand/50 p-6 font-display text-lg leading-relaxed">
              “True growth comes from continuous improvement and
              accountability.”
              <span className="mt-2 block text-sm text-ink/50">
                — Sonia Tomas, The Salon Dr.
              </span>
            </div>
          </div>
        </Reveal>
      </div>
    </Section>
  );
}

const AUDIENCE = [
  {
    t: "Salon Owners & Managers",
    d: "Who want to lead teams more effectively, increase profitability and elevate the client experience.",
  },
  {
    t: "Aspiring Salon Leaders",
    d: "Developing the skills to step into managerial roles and drive salon success.",
  },
  {
    t: "Experienced Hairdressers",
    d: "Ready to grow beyond technical skill into business growth, client satisfaction and collaboration.",
  },
  {
    t: "Whole Salon Teams",
    d: "Committed to common goals, better communication and a thriving salon environment.",
  },
];

export function WhoFor() {
  return (
    <Section className="bg-sand/40">
      <Reveal>
        <div className="mx-auto max-w-2xl text-center">
          <Eyebrow>Who it's for</Eyebrow>
          <h2 className="mt-5 font-display-light text-4xl leading-tight sm:text-5xl">
            Built for owners and staff — because the gap lives between them.
          </h2>
        </div>
      </Reveal>
      <div className="mt-12 grid gap-5 md:grid-cols-2 lg:grid-cols-4">
        {AUDIENCE.map((a, i) => (
          <Reveal key={a.t} delay={i * 80}>
            <div className="h-full rounded-2xl bg-white p-7 shadow-[0_20px_50px_-40px_rgba(33,33,33,0.7)]">
              <div className="font-display text-4xl font-semibold text-blush">
                0{i + 1}
              </div>
              <h3 className="mt-3 font-display text-lg font-medium leading-snug">
                {a.t}
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-ink/60">{a.d}</p>
            </div>
          </Reveal>
        ))}
      </div>
      <Reveal>
        <div className="mt-12 text-center">
          <CTAButton className="px-8 py-4 text-base">
            Book Your Salon's Training Day
          </CTAButton>
        </div>
      </Reveal>
    </Section>
  );
}

const TESTIMONIALS = [
  {
    quote:
      "I've just been reflecting on our year and this time last year we did $21k and $1k of retail (grosse) and comparatively this year was $34k and over $4k in retail. Our stylist went from $800 a week to over $4k a week because she's now not scared of what to offer. I'm dead. I can't. You're unrealllllllll.",
    name: "Salon owner",
    role: "One year on from the training",
    stat: "$34k",
    statLabel: "year, up from $21k",
  },
  {
    quote:
      "After being so motivated from listening to today's call and the retail tips today I made an extra $431 today. Every client bought retail and 2 treatment upgrades. Also note I was on my own today.",
    name: "Rachael May",
    role: "Salon owner",
    stat: "+$431",
    statLabel: "extra in one day",
  },
  {
    quote:
      "11 retail products sold today $418.65. This week 42 retail products $1,734. And I almost made my total for the week we made $4945. And Sarah almost made her total she made $1136.",
    name: "Salon team",
    role: "Week one after training",
    stat: "$1,734",
    statLabel: "retail in one week",
  },
  {
    quote:
      "Hey beautiful I just needed to let you know how great we went after having you in the salon, our retail went up by 267%. But the everyone can't believe how different they felt with consultations, loved every second of it thank you a million!!! Xx",
    name: "Salon owner",
    role: "After the in-salon day",
    stat: "267%",
    statLabel: "retail increase",
  },
  {
    quote:
      "Today has been the best day at work I've had since coming back. All the girls are so motivated and focused. We are absolutely smashing the retail sales and all clients have walked out with products.",
    name: "Salon owner",
    role: "The day after Sonia's visit",
    stat: "100%",
    statLabel: "of clients took retail home",
  },
  {
    quote:
      "On Monday, our team had the absolute pleasure of an in-salon training day diving deep into retail, targets, and truly caring for our clients. It was one of those sessions that leaves you buzzing with new ideas, fresh motivation, and a reminder of why we do what we do. Sometimes you don't realise what your business — or your team — is missing until you meet someone like Sonia. Thank you, Sonia, for taking the time to travel all the way to Gunnedah and share your passion with Soul Hair Studio. We're feeling inspired and ready to take things to the next level.",
    name: "Soul Hair Studio",
    role: "Gunnedah, regional NSW",
    stat: "In-salon",
    statLabel: "whole-team training day",
  },
  {
    quote:
      "I almost didn't do it because we have done various courses and coaching over time and wasn't that convinced. But after we did the team was feeling motivated, recharged, they really loved Sonia's energy and laid back straight to the point approach. I really recommend this especially this time of year as we're coming into Christmas. It is an affordable commitment to really drive sales. We saw our retail go up by 80% in the first week.",
    name: "Salon owner",
    role: "Sceptical before, converted after",
    stat: "80%",
    statLabel: "retail lift, first week",
  },
];

export function Testimonial() {
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);
  const count = TESTIMONIALS.length;

  useEffect(() => {
    if (paused) return;
    const timer = window.setInterval(() => {
      setIndex((i) => (i + 1) % count);
    }, 7000);
    return () => window.clearInterval(timer);
  }, [paused, count]);

  const go = (dir: number) =>
    setIndex((i) => (i + dir + count) % count);

  return (
    <Section className="bg-ink text-cream">
      <Reveal>
        <div className="mx-auto max-w-2xl text-center">
          <Eyebrow>What salons are saying</Eyebrow>
          <h2 className="mt-5 font-display-light text-4xl leading-tight sm:text-5xl">
            The numbers, in their own words.
          </h2>
          <p className="mt-5 text-cream/65">
            Real messages from owners and teams after training day. No stock
            photos, no scripts.
          </p>
        </div>
      </Reveal>

      <Reveal delay={100}>
        <div
          className="relative mx-auto mt-12 max-w-4xl"
          onMouseEnter={() => setPaused(true)}
          onMouseLeave={() => setPaused(false)}
          onFocus={() => setPaused(true)}
          onBlur={() => setPaused(false)}
          aria-roledescription="carousel"
        >
          <div className="overflow-hidden rounded-[2rem] border border-cream/12 bg-cream/[0.06]">
            <div
              className="flex transition-transform duration-700 ease-[cubic-bezier(0.22,1,0.36,1)]"
              style={{ transform: `translateX(-${index * 100}%)` }}
            >
              {TESTIMONIALS.map((t, i) => (
                <figure
                  key={i}
                  className="w-full shrink-0 p-7 sm:p-10 md:p-12"
                  aria-hidden={i !== index}
                >
                  <div className="flex items-baseline gap-4">
                    <div className="font-display text-4xl font-semibold text-blush sm:text-5xl">
                      {t.stat}
                    </div>
                    <div className="text-[11px] uppercase tracking-[0.18em] text-cream/45">
                      {t.statLabel}
                    </div>
                  </div>
                  <blockquote className="mt-6 font-display-light text-xl leading-relaxed text-cream/90 sm:text-2xl">
                    “{t.quote}”
                  </blockquote>
                  <figcaption className="mt-7 flex items-center gap-4">
                    <span className="h-px w-10 bg-blush" />
                    <div>
                      <div className="font-display font-medium">{t.name}</div>
                      <div className="text-sm text-cream/50">{t.role}</div>
                    </div>
                  </figcaption>
                </figure>
              ))}
            </div>
          </div>

          <div className="mt-6 flex items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              {TESTIMONIALS.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setIndex(i)}
                  aria-label={`Show testimonial ${i + 1}`}
                  aria-current={i === index}
                  className={`h-2 rounded-full transition-all duration-300 ${
                    i === index ? "w-8 bg-blush" : "w-2 bg-cream/25 hover:bg-cream/50"
                  }`}
                />
              ))}
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => go(-1)}
                aria-label="Previous testimonial"
                className="grid h-10 w-10 place-items-center rounded-full border border-cream/20 text-cream/70 transition hover:border-blush hover:text-blush"
              >
                ←
              </button>
              <span className="w-12 text-center text-xs tabular-nums text-cream/40">
                {index + 1} / {count}
              </span>
              <button
                onClick={() => go(1)}
                aria-label="Next testimonial"
                className="grid h-10 w-10 place-items-center rounded-full border border-cream/20 text-cream/70 transition hover:border-blush hover:text-blush"
              >
                →
              </button>
            </div>
          </div>
        </div>
      </Reveal>

      <Reveal delay={160}>
        <p className="mt-8 text-center text-xs text-cream/35">
          Results shared by salon owners and their teams. Individual results vary.
        </p>
      </Reveal>
    </Section>
  );
}
